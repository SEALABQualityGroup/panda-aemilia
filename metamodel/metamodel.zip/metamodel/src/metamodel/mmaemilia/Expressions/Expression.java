/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package metamodel.mmaemilia.Expressions;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Expression</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see metamodel.mmaemilia.Expressions.ExpressionsPackage#getExpression()
 * @model
 * @generated
 */
public interface Expression extends EObject {
} // Expression
