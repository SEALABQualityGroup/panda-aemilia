/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package metamodel.mmaemilia;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Input Interaction</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see metamodel.mmaemilia.mmaemiliaPackage#getInputInteraction()
 * @model
 * @generated
 */
public interface InputInteraction extends LocalInteraction {
} // InputInteraction
