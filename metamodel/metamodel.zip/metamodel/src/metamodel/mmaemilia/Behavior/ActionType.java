/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package metamodel.mmaemilia.Behavior;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Action Type</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see metamodel.mmaemilia.Behavior.BehaviorPackage#getActionType()
 * @model
 * @generated
 */
public interface ActionType extends EObject {
} // ActionType
