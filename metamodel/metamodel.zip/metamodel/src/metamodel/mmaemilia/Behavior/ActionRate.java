/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package metamodel.mmaemilia.Behavior;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Action Rate</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see metamodel.mmaemilia.Behavior.BehaviorPackage#getActionRate()
 * @model abstract="true"
 * @generated
 */
public interface ActionRate extends EObject {
} // ActionRate
