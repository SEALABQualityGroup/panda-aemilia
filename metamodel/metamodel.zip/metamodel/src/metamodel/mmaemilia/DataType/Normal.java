/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package metamodel.mmaemilia.DataType;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Normal</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see metamodel.mmaemilia.DataType.DataTypePackage#getNormal()
 * @model
 * @generated
 */
public interface Normal extends DataType {
} // Normal
