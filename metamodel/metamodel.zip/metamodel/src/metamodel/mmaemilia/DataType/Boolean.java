/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package metamodel.mmaemilia.DataType;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Boolean</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see metamodel.mmaemilia.DataType.DataTypePackage#getBoolean()
 * @model
 * @generated
 */
public interface Boolean extends Normal {
} // Boolean
