/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package metamodel.mmaemilia;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Output Interaction</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see metamodel.mmaemilia.mmaemiliaPackage#getOutputInteraction()
 * @model
 * @generated
 */
public interface OutputInteraction extends LocalInteraction {
} // OutputInteraction
